"""
A tab widget whose tab strip wraps onto as many rows as it needs.

``QTabWidget`` cannot do this. Its bar lays out in a single row and,
when that overflows, either scrolls (hiding tabs behind arrows) or
elides the labels to nothing; ``setUsesScrollButtons(False)`` only
swaps one for the other. Subclassing ``QTabBar`` does not help either:
``tabRect``/``tabAt`` are not virtual, so painting tabs at wrapped
positions would leave hit-testing still laid out in one row and clicks
would select the wrong tab.

So the strip here is a row of checkable buttons in a flow layout over
a ``QStackedWidget``, exposing the slice of ``QTabWidget``'s API this
project actually uses. Real user request: "maybe the subtabs for more
dense tabs like analysis need to go over multiple lines so they are
always visible when the window is smaller" -- worst case is the
Analysis sub-tabs (5) inside an already-narrow side panel, but the
canvas strip has 6, so this is applied to all of them rather than
special-cased.

``addTab`` also takes an optional ``icon`` -- used for the top-level
side-panel launcher (Load/Save/Compare, Processing, Advanced
Processing, Fitting, Relaxation, Applications, Simulations), which
needed a row of icon tiles rather than plain text buttons, while every
other (sub-tab) caller keeps its existing text-only look by simply not
passing one.
"""

from __future__ import annotations

from PySide6.QtCore import QPoint, QRect, QSize, Qt, Signal
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import (
    QButtonGroup, QHBoxLayout, QLabel, QLayout, QSizePolicy, QStackedWidget, QToolButton,
    QVBoxLayout, QWidget,
)


class FlowLayout(QLayout):
    """Lays items left to right, wrapping to a new row when the next
    item would not fit -- Qt's own documented flow-layout pattern.

    ``heightForWidth`` is what makes the wrapping real: the layout
    reports the height it needs *for a given width*, so a parent
    shrinking horizontally is told to give it more vertical space
    rather than clipping the overflow."""

    def __init__(self, parent=None, margin: int = 0, spacing: int = 4) -> None:
        super().__init__(parent)
        self._items: list = []
        self.setContentsMargins(margin, margin, margin, margin)
        self.setSpacing(spacing)

    def addItem(self, item) -> None:  # noqa: N802 -- Qt's own casing
        self._items.append(item)

    def count(self) -> int:
        return len(self._items)

    def itemAt(self, index):  # noqa: N802
        return self._items[index] if 0 <= index < len(self._items) else None

    def takeAt(self, index):  # noqa: N802
        return self._items.pop(index) if 0 <= index < len(self._items) else None

    def expandingDirections(self):  # noqa: N802
        return Qt.Orientation(0)

    def hasHeightForWidth(self) -> bool:  # noqa: N802
        return True

    def heightForWidth(self, width: int) -> int:  # noqa: N802
        return self._layout(QRect(0, 0, width, 0), apply=False)

    def setGeometry(self, rect) -> None:  # noqa: N802
        super().setGeometry(rect)
        self._layout(rect, apply=True)

    def sizeHint(self) -> QSize:  # noqa: N802
        """One row's worth, as a *starting* hint only.

        The real height always comes from :meth:`heightForWidth`; a
        flow layout has no single natural size, since its height is
        entirely a function of the width it is given."""
        width = 0
        height = 0
        spacing = self.spacing()
        for item in self._items:
            hint = item.sizeHint()
            width += hint.width() + spacing
            height = max(height, hint.height())
        margins = self.contentsMargins()
        return QSize(max(0, width - spacing) + margins.left() + margins.right(),
                     height + margins.top() + margins.bottom())

    def minimumSize(self) -> QSize:  # noqa: N802
        size = QSize()
        for item in self._items:
            size = size.expandedTo(item.minimumSize())
        margins = self.contentsMargins()
        return size + QSize(margins.left() + margins.right(),
                            margins.top() + margins.bottom())

    def _layout(self, rect, apply: bool) -> int:
        """Place (or just measure) the items inside ``rect``. Returns
        the total height used."""
        margins = self.contentsMargins()
        x = rect.x() + margins.left()
        y = rect.y() + margins.top()
        right = rect.right() - margins.right()
        row_height = 0
        spacing = self.spacing()
        for item in self._items:
            hint = item.sizeHint()
            if row_height and x + hint.width() > right:
                x = rect.x() + margins.left()
                y += row_height + spacing
                row_height = 0
            if apply:
                item.setGeometry(QRect(QPoint(x, y), hint))
            x += hint.width() + spacing
            row_height = max(row_height, hint.height())
        return y + row_height + margins.bottom() - rect.y()


class _TabBar(QWidget):
    """The strip itself -- a widget whose height genuinely depends on
    its width.

    Both overrides are load-bearing, and their absence is what stopped
    nested strips wrapping. Qt only consults ``heightForWidth`` when
    the widget's **size policy** says to (``setHeightForWidth(True)``);
    without it a parent layout sizes the strip from ``sizeHint`` alone,
    which is one row tall, and every wrapped row is simply clipped.
    That went unnoticed for the top-level strips because they sit
    directly in the window and get their full width, so they rarely
    needed a second row -- the Analysis sub-tabs, five buttons inside
    an already-narrow side panel, always do.
    """

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        policy = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Minimum)
        policy.setHeightForWidth(True)
        self.setSizePolicy(policy)

    def hasHeightForWidth(self) -> bool:  # noqa: N802
        return True

    def heightForWidth(self, width: int) -> int:  # noqa: N802
        layout = self.layout()
        return layout.heightForWidth(width) if layout else super().heightForWidth(width)

    def resizeEvent(self, event) -> None:  # noqa: N802
        """Re-ask the parent layout for space when the width changes.

        A flow layout's height is a function of its width, so a resize
        that rewraps the buttons changes how much vertical space this
        strip needs -- without invalidating, the parent keeps the
        height it computed for the old width."""
        super().resizeEvent(event)
        self.updateGeometry()


class WrappingTabWidget(QWidget):
    """``QTabWidget``'s API, with a tab strip that wraps.

    Only the parts this project uses are implemented -- see the module
    docstring. ``currentChanged`` carries the new index, matching
    ``QTabWidget``'s own signal, so existing connections are unchanged.
    """

    currentChanged = Signal(int)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._bar = _TabBar(self)
        self._bar_layout = FlowLayout(self._bar)
        self._buttons: list[QToolButton] = []
        self._labels: list[str] = []
        self._group = QButtonGroup(self)
        self._group.setExclusive(True)
        self._stack = QStackedWidget(self)
        # Stands in for the strip once something else (the main
        # toolbar) does the switching -- see setTabBarVisible.
        self._heading = QLabel(self)
        heading_font = self._heading.font()
        heading_font.setBold(True)
        self._heading.setFont(heading_font)
        self._heading.hide()

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(2)
        layout.addWidget(self._bar)
        layout.addWidget(self._heading)
        layout.addWidget(self._stack, 1)

        self._stack.currentChanged.connect(self._on_stack_changed)

    # -- QTabWidget API ------------------------------------------------

    #: Icon size for a tab added with ``icon=`` -- big enough to read
    #: as a launcher tile (see the module docstring) rather than a
    #: decorative sliver next to the label. 28px was too small for
    #: these particular icons: real user report, "the icons in the
    #: new GUI are (very ugly) versions of my originals" -- the source
    #: files were never swapped for anything else (verified byte-for-
    #: byte identical to the user's own reference images), but each is
    #: a detailed multi-colour illustration around 354x354, and
    #: downscaling that much fine linework to 28px lost it almost
    #: entirely (confirmed by rendering at both sizes: e.g. the
    #: Processing FID icon's individual oscillation lines merged into
    #: a single muddy wedge). 48px keeps the linework legible at the
    #: sizes actually tested (28/40/48/56).
    _ICON_SIZE = QSize(48, 48)

    #: The compact toolbar (notes 8.5): a small laptop screen is helped by shorter,
    #: narrower buttons, not by shrinking every piece of text in the program. The
    #: label keeps the interface font; only the icon, the padding and the gap
    #: between buttons shrink.
    _COMPACT_ICON_SIZE = QSize(24, 24)
    _COMPACT_STYLE = "QToolButton { padding: 2px 5px; }"
    _COMPACT_SPACING = 2
    _NORMAL_SPACING = 4

    def isCompact(self) -> bool:  # noqa: N802
        return bool(getattr(self, "_compact", False))

    def setCompact(self, compact: bool) -> None:  # noqa: N802
        """Shrink (or restore) the buttons' icons and padding, leaving the font alone."""
        self._compact = bool(compact)
        self._bar_layout.setSpacing(self._COMPACT_SPACING if self._compact else self._NORMAL_SPACING)
        for button in self._buttons:
            self._style_button(button)
        self._bar_layout.invalidate()
        self._bar.updateGeometry()

    def _style_button(self, button: QToolButton) -> None:
        if not button.icon().isNull():
            button.setIconSize(self._COMPACT_ICON_SIZE if self.isCompact() else self._ICON_SIZE)
        button.setStyleSheet(self._COMPACT_STYLE if self.isCompact() else "")

    def addTab(self, widget: QWidget, label: str, icon: QIcon | None = None) -> int:  # noqa: N802
        index = self._stack.addWidget(widget)
        button = QToolButton(self._bar)
        button.setText(label)
        button.setCheckable(True)
        button.setToolTip(label)
        button.setFocusPolicy(Qt.FocusPolicy.TabFocus)
        if icon is not None:
            # Icon-above-text, launcher-tile style -- every other
            # (sub-tab) caller omits icon and keeps the plain
            # text-only button this class always had.
            button.setIcon(icon)
            button.setIconSize(self._ICON_SIZE)
            button.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextUnderIcon)
        if self.isCompact():
            self._style_button(button)
        button.clicked.connect(lambda _checked, w=widget: self.setCurrentWidget(w))
        self._group.addButton(button)
        self._bar_layout.addWidget(button)
        self._buttons.append(button)
        self._labels.append(label)
        if self._stack.count() == 1:
            button.setChecked(True)
        return index

    def count(self) -> int:
        return self._stack.count()

    def widget(self, index: int) -> QWidget | None:
        return self._stack.widget(index)

    def indexOf(self, widget: QWidget) -> int:  # noqa: N802
        return self._stack.indexOf(widget)

    def tabText(self, index: int) -> str:  # noqa: N802
        return self._labels[index] if 0 <= index < len(self._labels) else ""

    def currentIndex(self) -> int:  # noqa: N802
        return self._stack.currentIndex()

    def setCurrentIndex(self, index: int) -> None:  # noqa: N802
        self._stack.setCurrentIndex(index)

    def currentWidget(self) -> QWidget | None:  # noqa: N802
        return self._stack.currentWidget()

    def setCurrentWidget(self, widget: QWidget) -> None:  # noqa: N802
        self._stack.setCurrentWidget(widget)

    def setTabVisible(self, index: int, visible: bool) -> None:  # noqa: N802
        """Hide a tab's button, matching ``QTabWidget.setTabVisible``.

        The page stays in the stack -- hiding a tab must not renumber
        the others, since callers hold indices from ``indexOf``."""
        if 0 <= index < len(self._buttons):
            self._buttons[index].setVisible(visible)

    def isTabVisible(self, index: int) -> bool:  # noqa: N802
        """Whether this tab is *meant* to be shown.

        ``not isHidden()``, not ``isVisible()``: the latter is False
        for every child of a window that has not been shown yet, so it
        would report a perfectly visible tab as hidden simply because
        the widget tree is not on screen. ``QTabWidget.isTabVisible``
        reports the requested state, and so does this."""
        if 0 <= index < len(self._buttons):
            return not self._buttons[index].isHidden()
        return False

    # -- beyond QTabWidget --------------------------------------------

    def setTabBarVisible(self, visible: bool, *, show_heading: bool = False) -> None:  # noqa: N802
        """Show or hide the strip of tab buttons.

        Hidden, the pages are switched from outside (the main
        toolbar's menus) and this is just a stack. ``show_heading``
        then puts the current tab's name where the strip was, since
        with no strip nothing else on screen says which page this is."""
        self._bar.setVisible(visible)
        self._heading.setVisible(not visible and show_heading)
        self._heading.setText(self.tabText(self.currentIndex()))

    def setCornerWidget(self, widget: QWidget) -> None:  # noqa: N802
        """Put ``widget`` at the right-hand end of the strip, beside the
        tab buttons (``QTabWidget.setCornerWidget``'s top-right corner):
        controls for the page on show, by the page rather than in a side
        panel -- e.g. the Fit view's peak browser."""
        layout = self._layout()
        index = layout.indexOf(self._bar)
        if index < 0:
            raise RuntimeError("The tab strip has been taken; it has no corner.")
        layout.removeWidget(self._bar)
        holder = QWidget(self)
        row = QHBoxLayout(holder)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(6)
        row.addWidget(self._bar, 1)
        row.addWidget(widget, 0, Qt.AlignmentFlag.AlignTop)
        layout.insertWidget(index, holder)
        self._corner = widget

    def cornerWidget(self) -> QWidget | None:  # noqa: N802
        return getattr(self, "_corner", None)

    def isTabBarVisible(self) -> bool:  # noqa: N802
        return not self._bar.isHidden()

    def takeTabBar(self) -> QWidget:  # noqa: N802
        """Remove the strip from this widget and hand it back, so a
        caller can place it somewhere else in the window.

        The strip stays fully live -- its buttons still drive this
        widget's stack -- because the wiring is signal-based, not
        positional. Used to run the launcher tiles as one persistent
        row across the top of the window (explicit user request) while
        the pages they switch stay in the left column; without this the
        strip can only sit directly above its own pages, which in a
        narrow side panel means the tiles wrap to three or four rows
        and eat the panel.

        The caller owns the returned widget and must parent it, or it
        is destroyed. Idempotent: calling twice returns the same strip.
        """
        self._layout().removeWidget(self._bar)
        self._bar.setParent(None)
        self._bar.setVisible(True)
        return self._bar

    def _layout(self):
        return self.layout()

    def headingText(self) -> str:  # noqa: N802
        """The heading shown in place of a hidden strip ('' if none)."""
        return self._heading.text() if not self._heading.isHidden() else ""

    # -- internals -----------------------------------------------------

    def _on_stack_changed(self, index: int) -> None:
        """Keep the buttons in step with the stack however the page was
        changed -- a click, ``setCurrentWidget``, or a caller setting
        the index directly."""
        if 0 <= index < len(self._buttons):
            self._buttons[index].setChecked(True)
        self._heading.setText(self.tabText(index))
        self.currentChanged.emit(index)
