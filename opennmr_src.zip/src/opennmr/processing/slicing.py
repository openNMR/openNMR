"""
Extract 1D traces (rows/columns) from a 2D :class:`NMRSpectrum`.

An extracted trace is just a 1D :class:`NMRSpectrum` -- the same class
used everywhere else -- carrying provenance (which row/column, at what
shift) in ``metadata.raw["slice"]`` rather than in a separate ad-hoc
dict shape. That unification is also what removes the need for
``nmrtools2``'s ``prepare_trace_for_fit`` adapter: a trace can be
handed straight to :func:`opennmr.processing.fitting.fit_spectrum`.

Ported from ``nmrtools2``'s ``NMR2d_get_trace``/``NMR2D_get_slices``
(``two_d.py``).
"""

from __future__ import annotations

import numpy as np

from ..core.spectrum import NMRAxis, NMRMetadata, NMRSpectrum
from .ft import hilbert_imaginary


#: ``metadata.raw`` entries holding *acquisition* parameters (Bruker's
#: acqus/acqu2s/acqu3s, X-Pulse's exp_params and JCAMP header) --
#: copied onto an extracted trace, see :func:`get_trace`.
_ACQUISITION_KEYS = ("acqus", "acqu2s", "acqu3s", "exp_params", "params")


def _f2_quadrature_is_spent(spectrum: NMRSpectrum) -> bool:
    """A genuine hypercomplex 2D (FnMODE 4/5/6), whose stored imaginary
    part is F1's -- see ``MainWindow._f2_quadrature_is_spent``."""
    raw = spectrum.metadata.raw or {}
    try:
        fn_mode = int(raw.get("fn_mode", 1))
    except (TypeError, ValueError):
        return False
    return spectrum.ndim == 2 and not spectrum.is_pseudo_2d and fn_mode in (4, 5, 6)


def get_trace(spectrum: NMRSpectrum, axis: str = "f1", index: int | None = None,
              shift: float | None = None, width: int = 1, combine: str = "sum",
              window: tuple[float, float] | None = None) -> NMRSpectrum:
    """Extract a single 1D trace (row or column) from a 2D
    :class:`NMRSpectrum`.

    ``axis`` : ``"f1"`` fixes a position along F1 (``spectrum.axes[0]``,
    a *row* of ``spectrum.data``) and returns a trace running along F2.
    ``"f2"`` fixes a position along F2 (a *column*) and returns a trace
    running along F1.

    ``index`` : 1-based position along the fixed axis (TopSpin
    convention). ``shift`` : chemical shift (ppm), converted to the
    nearest index -- not valid for the pseudo-2D F1 axis (use ``index``
    instead, since slice number has no chemical-shift meaning).

    ``width``/``combine`` : sum or average this many adjacent points,
    centred on the selected position, for extra S/N.

    ``window`` : restrict the returned trace to this ppm range (only
    applied when the trace's own axis is a chemical shift).

    The returned spectrum's ``metadata.raw["slice"]`` records
    ``slice_type`` (``"row"``/``"column"``), ``index``, ``shift``,
    ``shift_unit`` (``"ppm"`` or ``"index"``), ``width``, and
    ``dimension`` (``"F1"`` for a column, ``"F2"`` for a row). The 2D's
    acquisition parameter tables are carried over too, so a named pulse
    or delay (``P3``, ``D1``, ...) can still be looked up on the trace.
    """
    if spectrum.ndim != 2:
        raise ValueError("get_trace expects a 2D NMRSpectrum.")
    if axis not in ("f1", "f2"):
        raise ValueError("axis must be 'f1' or 'f2'")
    if index is None and shift is None:
        raise ValueError("Either index or shift must be provided.")

    data = spectrum.data
    pseudo2d = spectrum.is_pseudo_2d
    fixed_axis = spectrum.axes[0] if axis == "f1" else spectrum.axes[1]
    n_fixed = data.shape[0] if axis == "f1" else data.shape[1]

    if index is not None:
        pos = int(index) - 1
        if pos < 0 or pos >= n_fixed:
            raise ValueError(f"index {index} out of range (1..{n_fixed})")
    else:
        if axis == "f1" and pseudo2d:
            raise ValueError(
                "shift cannot be used to select an F1 position for pseudo-2D "
                "data; use index instead."
            )
        pos = int(np.argmin(np.abs(fixed_axis.values("ppm") - shift)))

    if axis == "f1" and pseudo2d:
        actual_shift = float(fixed_axis.index[pos])
        shift_unit = "index"
    else:
        actual_shift = float(fixed_axis.values("ppm")[pos])
        shift_unit = "ppm"
    actual_index = pos + 1

    half = width // 2
    lo = max(0, pos - half)
    hi = min(n_fixed, lo + width)
    lo = max(0, hi - width)

    data_imag = spectrum.data_imag

    if axis == "f1":
        block = data[lo:hi, :]
        y = block.sum(axis=0) if combine == "sum" else block.mean(axis=0)
        y_imag = None
        if data_imag is not None:
            block_imag = data_imag[lo:hi, :]
            y_imag = block_imag.sum(axis=0) if combine == "sum" else block_imag.mean(axis=0)
        trace_axis = spectrum.axes[1]
        slice_type = "row"
        nucleus = spectrum.metadata.nucleus
        sfo1 = spectrum.metadata.sfo1
    else:
        block = data[:, lo:hi]
        y = block.sum(axis=1) if combine == "sum" else block.mean(axis=1)
        y_imag = None
        if data_imag is not None:
            block_imag = data_imag[:, lo:hi]
            y_imag = block_imag.sum(axis=1) if combine == "sum" else block_imag.mean(axis=1)
        trace_axis = spectrum.axes[0]
        slice_type = "column"
        if spectrum.metadata.homonuclear:
            nucleus, sfo1 = spectrum.metadata.nucleus, spectrum.metadata.sfo1
        else:
            nucleus, sfo1 = spectrum.metadata.nucleus_indirect, spectrum.metadata.sfo1_indirect

    x_is_ppm = trace_axis.kind == "frequency"
    y = np.asarray(y)
    if y_imag is not None:
        y_imag = np.asarray(y_imag)
    # A row of a hypercomplex 2D (States, States-TPPI, Echo-Antiecho)
    # runs along F2, but the imaginary part stored with the 2D is F1's
    # (TopSpin's 2ri): the decode consumed F2's. Phasing the row with
    # F1's imaginary is not a phase change at all -- at an F1-absorptive
    # peak row 2ri is close to zero, so dragging the phase by 90 degrees
    # barely changed the trace (user report, 2026-10-15). F2's imaginary
    # is rebuilt from the row by the Hilbert transform instead.
    imaginary_from = None
    if axis == "f1" and y_imag is not None and _f2_quadrature_is_spent(spectrum):
        y_imag = hilbert_imaginary(y)
        imaginary_from = "hilbert"

    if window is not None and x_is_ppm:
        lo_w, hi_w = sorted(window)
        ppm = trace_axis.values("ppm")
        mask = (ppm >= lo_w) & (ppm <= hi_w)
        new_axis = NMRAxis(
            kind="frequency", ppm=ppm[mask],
            hz=trace_axis.hz[mask] if trace_axis.hz is not None else None,
        )
        y = y[mask]
        if y_imag is not None:
            y_imag = y_imag[mask]
    else:
        new_axis = trace_axis

    # The acquisition parameter tables travel with the trace: they are
    # facts about the experiment the trace came from (pulse lengths,
    # delays, spinning rate), and without them nothing that asks for
    # one by name works on a kept slice -- VOCS on an F1 column of a
    # J-HMQC failed with "no recorded acquisition parameters" (user
    # report). Processing tables (procs/proc2s) are deliberately not
    # carried: they describe how the *2D* was processed, not the trace.
    parent_raw = spectrum.metadata.raw or {}
    raw = {key: parent_raw[key] for key in _ACQUISITION_KEYS if key in parent_raw}
    raw["slice"] = {
        "slice_type": slice_type, "index": actual_index, "shift": actual_shift,
        "shift_unit": shift_unit, "width": width,
        # Which dimension the trace runs along -- a column runs along F1.
        "dimension": "F2" if axis == "f1" else "F1",
    }
    if imaginary_from:
        # Said in the trace's own record, so a log or a reader of the
        # metadata knows the imaginary part is reconstructed.
        raw["slice"]["imaginary"] = imaginary_from
    metadata = NMRMetadata(
        vendor=spectrum.metadata.vendor, nucleus=nucleus, sfo1=sfo1,
        source_path=spectrum.metadata.source_path, procno=spectrum.metadata.procno,
        pseudo_2d=pseudo2d, raw=raw,
    )
    return NMRSpectrum(data=y, axes=[new_axis], metadata=metadata, data_imag=y_imag)


def get_slices(spectrum: NMRSpectrum, rows: list[int] | None = None, row_shifts: list[float] | None = None,
                row_width: int = 1, columns: list[int] | None = None, column_shifts: list[float] | None = None,
                column_width: int = 1, combine: str = "sum", window: tuple[float, float] | None = None,
                normalise: bool = False) -> dict:
    """Extract multiple row and/or column traces from a 2D
    :class:`NMRSpectrum`. A thin batch wrapper around :func:`get_trace`.

    ``rows``/``row_shifts`` : 1-based F1 indices / F1 chemical shifts
    (ppm) of rows to extract (may be combined; duplicates extracted
    once). ``columns``/``column_shifts`` : likewise for F2.

    ``normalise`` : if True, scale every extracted trace to its own
    maximum absolute intensity.

    Returns a dict with keys ``"rows"`` and ``"columns"``, each a list
    of :class:`NMRSpectrum` traces sorted by position along the fixed
    axis.
    """
    slices = {"rows": [], "columns": []}

    def _collect(axis, indices, shifts, width):
        out = []
        seen_index = set()

        for idx in (indices or []):
            if idx in seen_index:
                continue
            seen_index.add(idx)
            out.append(get_trace(spectrum, axis=axis, index=idx, width=width, combine=combine, window=window))

        for sh in (shifts or []):
            trace = get_trace(spectrum, axis=axis, shift=sh, width=width, combine=combine, window=window)
            trace_index = trace.metadata.raw["slice"]["index"]
            if trace_index in seen_index:
                continue
            seen_index.add(trace_index)
            out.append(trace)

        out.sort(key=lambda t: t.metadata.raw["slice"]["index"])
        return out

    if rows is not None or row_shifts is not None:
        slices["rows"] = _collect("f1", rows, row_shifts, row_width)
    if columns is not None or column_shifts is not None:
        slices["columns"] = _collect("f2", columns, column_shifts, column_width)

    if normalise:
        for group in slices.values():
            for tr in group:
                m = np.max(np.abs(tr.data))
                if m > 0:
                    tr.data = tr.data / m

    return slices


def build_pseudo2d(traces: list[NMRSpectrum]) -> NMRSpectrum:
    """Stack a list of already-computed 1D traces -- all sharing the
    same chemical-shift (ppm) axis -- into one pseudo-2D
    :class:`NMRSpectrum`. The reverse of :func:`get_slices`' own row
    extraction: instead of pulling slices *out* of a pseudo-2D
    dataset, this puts a derived series *back together* into one, so
    it can be viewed, compared and exported exactly like any other
    pseudo-2D dataset.

    Explicit user request, for the GUI's Fitting panel: "an option to
    have these fitted peaks be exported to a pseudo-2d dataset" --
    e.g. one trace per slice holding that slice's reconstructed fitted
    lineshape (Isotropic), or its raw data masked to the integration
    regions that produced its integral (Integration). Deliberately
    generic rather than baked into either caller: both need exactly
    this same "stack compatible 1D traces into a 2D dataset" step,
    and nothing about it is specific to fitting.

    Every trace must be 1D and carry a chemical-shift axis (``ppm``
    set); a trace with no ppm values, or one whose ppm axis doesn't
    match the first trace's (same length, matching values), raises
    rather than silently interpolating or truncating -- interpolating
    would invent intensity values that were never actually measured
    or fitted at those positions.
    """
    if len(traces) < 2:
        raise ValueError(
            "build_pseudo2d needs at least two traces – a single slice "
            "is not a series."
        )

    first = traces[0]
    if first.ndim != 1:
        raise ValueError(f"Trace 1 is not 1D (ndim={first.ndim}).")
    ref_axis = first.axes[0]
    ref_ppm = ref_axis.ppm
    if ref_ppm is None:
        raise ValueError(
            "Trace 1 has no chemical-shift (ppm) axis – build_pseudo2d "
            "only stacks frequency-domain traces."
        )

    rows = [np.asarray(first.data, dtype=float)]
    for i, trace in enumerate(traces[1:], start=2):
        if trace.ndim != 1:
            raise ValueError(f"Trace {i} is not 1D (ndim={trace.ndim}).")
        axis = trace.axes[0]
        if (axis.ppm is None or len(axis.ppm) != len(ref_ppm)
                or not np.allclose(axis.ppm, ref_ppm)):
            raise ValueError(
                f"Trace {i} does not share trace 1's ppm axis – every "
                "trace must be measured/fitted on the same axis to be "
                "stacked into one pseudo-2D dataset."
            )
        rows.append(np.asarray(trace.data, dtype=float))

    data = np.vstack(rows)
    f1_axis = NMRAxis(kind="index", index=np.arange(1, len(traces) + 1), label="Slice")
    f2_axis = NMRAxis(kind="frequency", ppm=ref_ppm, hz=ref_axis.hz)
    metadata = NMRMetadata(
        vendor=first.metadata.vendor,
        nucleus=first.metadata.nucleus,
        sfo1=first.metadata.sfo1,
        source_path=first.metadata.source_path,
        procno=first.metadata.procno,
        pseudo_2d=True,
    )
    return NMRSpectrum(data=data, axes=[f1_axis, f2_axis], metadata=metadata)
