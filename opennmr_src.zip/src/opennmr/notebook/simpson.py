"""
Tools for importing SIMPSON-simulated NMR spectra and pulse-shape
files, and for plotting them either alone or alongside spectra
imported with nmrtools.one_d.NMR1dimport.

Workflow
--------
    SIMPSONimport     -> import a SIMPSON .spe/.dat/.csdf(SIMP-text) spectrum
    CSDMimport        -> import a *genuine* CSDM/JSON file (needs csdmpy)
    SIMPSONread_shape        -> import a SIMPSON pulse-shape (.shape) file
    SIMPSONread_fid          -> import a raw SIMPSON FID (time domain, no FFT)
    SIMPSONapodization_window -> compute an apodization window on its own
    SIMPSONplot_fid          -> plot a FID, optionally with its apodization window
    SIMPSONread_single_point_fid -> first point of one single-point FID file
    SIMPSONread_fid_series   -> first point of a series of single-point FID files
    SIMPSONplot_1d_stack     -> stacked-spectrum plot from a list of result dicts
                        (mix NMR1dimport / SIMPSONimport / CSDMimport freely)
    SIMPSONplot_shape        -> amplitude/phase plot of a pulse-shape file
    SIMPSONplot_fid_series   -> plot first-point intensity vs a swept quantity

Design notes
------------
NMR1dplot (in one_d.py) is left untouched: it still only accepts
Bruker directory paths and calls NMR1dimport internally. SIMPSONplot_1d_stack
below re-implements its stacking/offset/colour/label logic against a
list of *already-imported* result dicts instead, so spectra from any
importer that produces a compatible dict can be plotted together.
This is a deliberate duplication of ~40 lines of one_d.py's plotting
loop, not a wrapper around it -- if NMR1dplot's stacking logic changes
later, this needs updating in step. Worth consolidating into one
shared function if that drift becomes a problem in practice.

SIMPSON files carry no observe frequency, so ppm conversion is
optional and only happens if you supply `nuclide` (+ `field`, or an
explicit `SFO1`). Confirmed against the real nmrtools.utils: despite
its name, find_gamma alone does NOT derive an SFO1 from a nuclide+field
pair -- it only ever returns {'Nuclide', 'gamma'} (gamma in Hz/T); every
usage of it in one_d.py already has SFO1 known in advance (read from a
Bruker acqus file), and find_gamma's role there is picking the
canonical nuclide label given a known SFO1, not the reverse. The actual
nuclide+field->SFO1 conversion nmrtools already has is
utils.compute_BF1_SFO1(nuclide, B0_tesla), which _resolve_SFO1_from_field()
below wraps.

`field` accepts two conventions, distinguished by type:

    - a string, e.g. "500" or "800" -- the conversational field name,
      i.e. the frequency (MHz) at which 1H resonates on that magnet
      ("a 500", "an 800"). Converted to Tesla via 1H's own
      gyromagnetic ratio before calling compute_BF1_SFO1.
    - a plain number, e.g. 11.7 or 18.8 -- the field strength itself,
      in Tesla, passed straight to compute_BF1_SFO1.

field=500 (no quotes) is therefore read as 500 Tesla, not a "500 MHz"
magnet -- use field="500" for that. This mirrors how spectroscopists
actually say both of these out loud, but the string/number distinction
is easy to trip over; if you'd rather not rely on it, pass SFO1
explicitly (or B0_tesla-as-float unambiguously) instead.

Design note: this conversational-field parsing only converts a string
frequency to Tesla; the underlying nuclide+field(Tesla)->SFO1 step is
utils.compute_BF1_SFO1, already shared by every *_spectrum_dict
producer in nmrtools (see that function's own docstring). Consider
moving _resolve_SFO1_from_field itself into utils.py (or teaching
compute_BF1_SFO1 the same string convention directly) if another module
ends up wanting the same "500"/"800" shorthand -- kept local to this
module for now since only this ask covers simpson.py.
"""

import os
import re

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cm as cmx

from .utils import find_gamma, NUC_label, compute_BF1_SFO1
from .plotting import (
    setup_plotting, get_stack_colormap, apply_tick_style, apply_spine_style, save_figure,
)

try:
    import csdmpy as cp
    _HAS_CSDMPY = True
except ImportError:
    _HAS_CSDMPY = False


# ============================================================
# Format sniffing (content, not extension)
# ============================================================

def _sniff_format(path):
    """
    Identify a SIMPSON-related file by its content rather than its
    extension -- SIMPSON's `fsave` names files however the .tcl script
    asked, so a `.csdf` extension is no guarantee of JSON/CSDM content
    (see module docstring). Returns one of 'simp', 'dat', 'shape'.
    """
    with open(path, 'r', errors='ignore') as f:
        head_lines = [f.readline() for _ in range(3)]

    first = head_lines[0].strip()

    if first.startswith('{'):
        raise ValueError(
            f"{path} looks like JSON (genuine CSDM format), not SIMPSON "
            f"SIMP text. Use CSDMimport() instead of SIMPSONimport()."
        )

    if first == 'SIMP':
        return 'simp'

    # No header line: either a 3-column (freq, real, imag) .dat file,
    # or a 2-column (amplitude, phase) .shape file.
    ncols = len(first.split())
    if ncols == 3:
        return 'dat'
    elif ncols == 2:
        return 'shape'
    else:
        raise ValueError(
            f"Could not identify SIMPSON file format for {path} "
            f"(first line has {ncols} columns, expected 2 or 3)."
        )


# ============================================================
# Low-level readers
# ============================================================

def _read_simp_text(path):
    """
    Parse a SIMPSON 'SIMP' text-format file (.spe, or a .csdf that is
    actually SIMP text -- see module docstring). Returns NP, SW, TYPE,
    real, imag, path. Does not build an x-axis; SIMPSONimport does
    that, since it depends on TYPE (SPE vs FID).
    """
    NP = SW = TYPE = None
    real, imag = [], []
    in_data = False

    with open(path, 'r') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if line.startswith('NP='):
                NP = int(line[3:])
            elif line.startswith('SW='):
                SW = float(line[3:])
            elif line.startswith('TYPE='):
                TYPE = line[5:]
            elif line == 'DATA':
                in_data = True
            elif line == 'END':
                break
            elif in_data:
                re_val, im_val = line.split()
                real.append(float(re_val))
                imag.append(float(im_val))

    if NP is None or SW is None:
        raise ValueError(f"{path}: missing NP/SW header – not a valid SIMPSON SIMP file.")
    if len(real) != NP:
        raise ValueError(
            f"{path}: header declares NP={NP} but {len(real)} data lines were read."
        )

    return {
        'NP': NP, 'SW': SW, 'TYPE': TYPE,
        'real': np.array(real), 'imag': np.array(imag), 'path': path,
    }


def _read_dat_text(path):
    """
    Parse a SIMPSON '-xreim' .dat file: three columns
    (freq_Hz, real, imag), no header. A single-point file (one data
    row -- e.g. an NP=1 efficiency-test FID) is loaded by np.loadtxt
    as a flat 1D array rather than an (1, 3) array, so that case is
    reshaped explicitly rather than being rejected.
    """
    data = np.loadtxt(path)
    if data.ndim == 1 and data.shape[0] == 3:
        data = data.reshape(1, 3)
    if data.ndim != 2 or data.shape[1] != 3:
        raise ValueError(f"{path}: expected 3 columns (freq, real, imag).")
    freq, real, imag = data[:, 0], data[:, 1], data[:, 2]
    return {'NP': len(freq), 'x_Hz': freq, 'TYPE': 'SPE', 'real': real, 'imag': imag, 'path': path}


def SIMPSONread_shape(path):
    """
    Read a SIMPSON pulse-shape file: two columns per line (amplitude,
    phase in degrees), no header, one row per point.

    Returns
    -------
    dict : 'amplitude', 'phase' (ndarrays), 'npoints', 'path'.
    """
    data = np.loadtxt(path)
    if data.ndim != 2 or data.shape[1] != 2:
        raise ValueError(f"{path}: expected 2 columns (amplitude, phase).")
    amplitude, phase = data[:, 0], data[:, 1]
    return {'amplitude': amplitude, 'phase': phase, 'npoints': len(amplitude), 'path': path}


_DURATION_IN_NAME = re.compile(r'(?<![\d.])(\d+(?:\.\d+)?)\s*(us|µs|μs|ms|ns)(?![a-z])', re.IGNORECASE)


def SIMPSONshape_duration_from_name(path):
    """
    The pulse length in microseconds written into a shape file's name --
    ``inv_pow_10.0us_W10_...shape`` -> 10.0 -- or ``None`` if the name
    holds none. The first number followed by us/µs (or ms, ns) counts.
    """
    match = _DURATION_IN_NAME.search(os.path.basename(str(path)))
    if not match:
        return None
    value = float(match.group(1))
    unit = match.group(2).lower()
    return value * {'ms': 1e3, 'ns': 1e-3}.get(unit, 1.0)


def SIMPSONshape_profile(path, duration_us=None):
    """
    A SIMPSON pulse shape described physically: RF amplitude, phase and the
    frequency sweep the phase encodes.

    SIMPSON's ``pulse_shaped <duration> <shape>`` gives every one of the N
    elements the same length, ``dt = duration / N`` -- so a shape written
    with N = 201 points for a 10 us pulse has 10/201 us elements, not
    10/200. ``duration_us`` : the pulse length; ``None`` takes it from the
    file name (:func:`SIMPSONshape_duration_from_name`), and without one
    there is no time axis (only point numbers) and no sweep or
    adiabaticity.

    The **frequency offset** is the slope of the phase,
    ``nu = (1/360) dphi/dt``, from consecutive elements (the phase is
    unwrapped first, so a phase written modulo 360 degrees reads as the
    continuous sweep it is). It is placed at the boundary between the two
    elements. This needs ``|nu| < 1/(2 dt)``; a shape sampled more coarsely
    than that cannot be unwrapped by anything.

    The **adiabaticity at the centre**, ``Q0 = 2 pi nu1^2 / |d nu/dt|``
    (``omega1^2 / |dOmega/dt|``), uses the amplitude and the sweep rate in
    the middle of the pulse -- where an isochromat at the carrier passes
    through resonance. Q0 >> 1 is adiabatic. ``None`` for a shape with no
    sweep there.

    Returns
    -------
    dict : 'npoints', 'path', 'duration_us' (or None), 'duration_source'
        ('given', 'file name' or None), 'dt_us', 't_us' (start of each
        element), 'amplitude_Hz', 'phase_deg' (as written),
        'phase_unwrapped_deg', 't_offset_us' and 'offset_Hz' (N - 1 values,
        at the element boundaries), 'max_amplitude_Hz', 'sweep_Hz'
        (last - first offset; its sign is the direction), 'q0' (or None).
    """
    shape = SIMPSONread_shape(path)
    n = shape['npoints']
    amplitude = np.asarray(shape['amplitude'], dtype=float)
    phase = np.asarray(shape['phase'], dtype=float)
    unwrapped = np.unwrap(phase, period=360.0)
    source = None
    if duration_us is not None and float(duration_us) > 0:
        duration_us, source = float(duration_us), 'given'
    else:
        duration_us = SIMPSONshape_duration_from_name(path)
        source = 'file name' if duration_us else None
    out = {'npoints': n, 'path': path, 'duration_us': duration_us,
           'duration_source': source, 'amplitude_Hz': amplitude, 'phase_deg': phase,
           'phase_unwrapped_deg': unwrapped, 'max_amplitude_Hz': float(np.max(np.abs(amplitude))),
           'dt_us': None, 't_us': np.arange(n, dtype=float), 't_offset_us': None,
           'offset_Hz': None, 'sweep_Hz': None, 'q0': None}
    if not duration_us or n < 2:
        return out
    dt_us = duration_us / n
    dt_s = dt_us * 1e-6
    offset = np.diff(unwrapped) / 360.0 / dt_s
    t_offset = np.arange(1, n, dtype=float) * dt_us
    out.update(dt_us=dt_us, t_us=np.arange(n, dtype=float) * dt_us,
               t_offset_us=t_offset, offset_Hz=offset,
               sweep_Hz=float(offset[-1] - offset[0]))
    if offset.size >= 3:
        centre = 0.5 * duration_us
        k = int(np.clip(np.searchsorted(t_offset, centre), 1, offset.size - 1))
        step = offset[k] - offset[k - 1]
        rate = step / ((t_offset[k] - t_offset[k - 1]) * 1e-6)
        nu1 = float(np.interp(centre, (np.arange(n) + 0.5) * dt_us, np.abs(amplitude)))
        # A constant offset differs from step to step only by rounding of the
        # written phase: that is no sweep, and no adiabaticity to quote.
        negligible = 1e-9 * max(float(np.max(np.abs(offset))), 1.0 / dt_s)
        if abs(step) > negligible and np.isfinite(rate):
            out['q0'] = float(2.0 * np.pi * nu1 ** 2 / abs(rate))
    return out


def SIMPSONdescribe_shape(profile):
    """One line for a profile from :func:`SIMPSONshape_profile`."""
    p = profile
    text = (f"{p['npoints']} points, maximum \u03bd\u2081 {p['max_amplitude_Hz'] / 1e3:.4g} kHz")
    if not p['duration_us']:
        return text + "; no pulse length (none given or in the file name), so no time axis or sweep."
    text += (f", {p['duration_us']:g} \u00b5s ({p['duration_source']}), "
             f"{p['dt_us'] * 1e3:.4g} ns per point")
    if p['offset_Hz'] is not None:
        lo, hi = p['offset_Hz'][0], p['offset_Hz'][-1]
        text += (f"; sweep {lo / 1e3:+.4g} \u2192 {hi / 1e3:+.4g} kHz "
                 f"({abs(p['sweep_Hz']) / 1e3:.4g} kHz)")
    if p['q0'] is not None:
        text += f"; adiabaticity at the centre Q\u2080 = {p['q0']:.3g}"
    return text + "."


# ============================================================
# FID processing (only used if a file's TYPE is FID, not SPE)
# ============================================================

def SIMPSONapodization_window(npoints, dt, kind='exponential', lb=0.0, gb=0.0,
                        sine_offset=0.0, sine_end=1.0):
    """
    Compute a time-domain apodization (window) function on its own --
    split out from fft_simpson_fid so it can be inspected/plotted
    (see SIMPSONplot_fid) before deciding what to apply.

    Parameters
    ----------
    npoints : int
    dt : float
        Dwell time in seconds (1/SW).
    kind : {'none', 'exponential', 'gaussian', 'lorentz_to_gauss',
            'sine', 'sine_squared'}, optional
        'none'              -- all ones, no apodization.
        'exponential'       -- exp(-pi*lb*t); `lb` in Hz (line
                                broadening added, as in fsave/TopSpin
                                'em').
        'gaussian'          -- exp(-(pi*gb*t)**2); `gb` in Hz (pure
                                Gaussian broadening, no resolution
                                gain).
        'lorentz_to_gauss'  -- exp(-pi*lb*t) * exp((pi*gb*t)**2); the
                                standard Lorentz-to-Gauss resolution-
                                enhancement window (needs both `lb`
                                and `gb`; if `gb` is too small relative
                                to `lb` and the acquisition time, this
                                blows up rather than tapering the end
                                of the FID -- check with SIMPSONplot_fid).
        'sine'              -- sin(pi*(sine_offset + (sine_end -
                                sine_offset)*t/t_max)); `sine_offset`/
                                `sine_end` in units of pi (0 = start of
                                sine, 1 = end), the same convention as
                                TopSpin's SSB-derived sine bells.
        'sine_squared'      -- square of the 'sine' window above.
    lb, gb : float, optional
        Broadening constants in Hz for 'exponential'/'gaussian'/
        'lorentz_to_gauss'. Default 0 (no broadening).
    sine_offset, sine_end : float, optional
        Start/end phase (in units of pi) for 'sine'/'sine_squared'.
        Defaults (0, 1) give a plain sine bell over the full FID.

    Returns
    -------
    t, window : ndarrays
        Time axis (s) and the window function, both length npoints.
    """
    t = np.arange(npoints) * dt
    t_max = t[-1] if npoints > 1 else dt

    if kind == 'none':
        window = np.ones(npoints)
    elif kind == 'exponential':
        window = np.exp(-np.pi * lb * t)
    elif kind == 'gaussian':
        window = np.exp(-(np.pi * gb * t) ** 2)
    elif kind == 'lorentz_to_gauss':
        window = np.exp(-np.pi * lb * t) * np.exp((np.pi * gb * t) ** 2)
    elif kind == 'sine':
        phase = sine_offset + (sine_end - sine_offset) * t / t_max
        window = np.sin(np.pi * phase)
    elif kind == 'sine_squared':
        phase = sine_offset + (sine_end - sine_offset) * t / t_max
        window = np.sin(np.pi * phase) ** 2
    else:
        raise ValueError(
            f"Unknown apodization kind '{kind}' – expected one of "
            f"'none', 'exponential', 'gaussian', 'lorentz_to_gauss', "
            f"'sine', 'sine_squared'."
        )

    return t, window


def apply_apodization(real, imag, SW, kind='exponential', **kwargs):
    """
    Multiply a FID by an SIMPSONapodization_window. Kept separate from
    fft_simpson_fid so the apodized time-domain FID itself (not just
    the resulting spectrum) can be inspected/plotted.

    Returns
    -------
    t, real_apod, imag_apod, window : ndarrays
    """
    npoints = len(real)
    dt = 1.0 / SW
    t, window = SIMPSONapodization_window(npoints, dt, kind=kind, **kwargs)
    fid = (np.asarray(real) + 1j * np.asarray(imag)) * window
    return t, fid.real, fid.imag, window


def fft_simpson_fid(real, imag, SW, apodization='exponential', apod_params=None,
                     line_broadening=0.0, zero_fill=None):
    """
    Fourier-transform a SIMPSON time-domain FID (TYPE=FID) into a
    frequency-domain spectrum, with an optional apodization window
    (see SIMPSONapodization_window for the available kinds) and zero-filling.
    This gives the same processing control over a SIMPSON FID that
    TopSpin has already silently applied to Bruker processed data by
    the time NMR1dimport reads it -- useful if you want simulated and
    experimental lineshapes processed identically rather than trusting
    SIMPSON's own `fsave -xreim` output.

    Parameters
    ----------
    real, imag : array-like
        Time-domain FID.
    SW : float
        Spectral width in Hz (dwell time = 1/SW).
    apodization : str, optional
        Window kind, passed to SIMPSONapodization_window. Default
        'exponential'. Pass 'none' to disable apodization entirely.
    apod_params : dict, optional
        Extra kwargs for SIMPSONapodization_window (e.g. {'gb': 20} for a
        Gaussian/Lorentz-to-Gauss window, or {'sine_offset': 0.5} for
        a shifted sine bell).
    line_broadening : float, optional
        Back-compatible shortcut for apod_params={'lb': ...} when
        apodization is 'exponential' (or 'lorentz_to_gauss'). Ignored
        if apod_params already sets 'lb'. Default 0 (none) -- this
        preserves the old fft_simpson_fid(real, imag, SW,
        line_broadening=...) call signature.
    zero_fill : int, optional
        Total number of points after zero-filling. Default: no
        zero-filling (uses len(real)).

    Returns
    -------
    x_Hz, real_spectrum, imag_spectrum : ndarrays
    """
    NP = len(real)
    apod_params = dict(apod_params) if apod_params else {}
    if line_broadening and 'lb' not in apod_params:
        apod_params['lb'] = line_broadening

    if apodization and apodization != 'none':
        _, real_a, imag_a, _ = apply_apodization(real, imag, SW, kind=apodization, **apod_params)
        fid = real_a + 1j * imag_a
    else:
        fid = np.asarray(real) + 1j * np.asarray(imag)

    dt = 1.0 / SW
    n_fft = zero_fill if zero_fill else NP
    spectrum = np.fft.fftshift(np.fft.fft(fid, n=n_fft))
    x_Hz = np.fft.fftshift(np.fft.fftfreq(n_fft, d=dt))

    return x_Hz, spectrum.real, spectrum.imag


def SIMPSONread_fid(path):
    """
    Read a SIMPSON time-domain FID file (TYPE=FID) without Fourier-
    transforming it -- for inspecting/apodizing/plotting the raw FID
    (see SIMPSONplot_fid) ahead of deciding what processing to use, or for
    feeding real/imag/SW into fft_simpson_fid by hand.

    Parameters
    ----------
    path : str

    Returns
    -------
    dict : 'real', 'imag' (ndarrays), 'NP', 'SW', 'dt' (=1/SW),
    't' (time axis, s), 'path'.
    """
    fmt = _sniff_format(path)
    if fmt == 'shape':
        raise ValueError(
            f"{path} looks like a SIMPSON pulse-shape file (2 columns, "
            f"no header), not a FID. Use SIMPSONread_shape() instead."
        )

    raw = _read_simp_text(path) if fmt == 'simp' else _read_dat_text(path)
    if raw.get('TYPE') != 'FID':
        raise ValueError(
            f"{path}: TYPE is '{raw.get('TYPE')}', not FID – this looks "
            f"like an already-processed spectrum. Use SIMPSONimport() "
            f"instead, or fft it yourself with fft_simpson_fid() if you "
            f"specifically need x_Hz/real_spectrum/imag_spectrum."
        )

    NP, SW = raw['NP'], raw['SW']
    dt = 1.0 / SW
    t = np.arange(NP) * dt

    return {'real': raw['real'], 'imag': raw['imag'], 'NP': NP, 'SW': SW,
            'dt': dt, 't': t, 'path': path}


# ============================================================
# ppm conversion helper (shared by SIMPSONimport / CSDMimport)
# ============================================================

def _resolve_SFO1_from_field(nuclide, field):
    """
    Resolve an SFO1 (MHz) for `nuclide` at `field`, accepting either
    convention -- see the module docstring:

    - a string (e.g. "500", "800"): the conversational field name --
      the frequency (MHz) at which 1H resonates on that magnet.
      Converted to Tesla via 1H's own gyromagnetic ratio, then handed
      to compute_BF1_SFO1.
    - a plain number (e.g. 11.7, 18.8): the field strength itself, in
      Tesla, passed straight to compute_BF1_SFO1.

    Does no nuclide+field->frequency physics itself -- that's entirely
    utils.compute_BF1_SFO1 (offset_ppm=0, so SFO1 == BF1: the
    on-resonance carrier, no explicit offset); this function's only
    job is normalising `field` to Tesla first when given as a
    conversational 1H-frequency string.

    Returns
    -------
    SFO1 : float (MHz)
    B0_tesla : float
    canonical_nuclide : str
        As returned by compute_BF1_SFO1 -- identical to `nuclide` here
        (see that function's docstring for when it can differ).
    """
    if isinstance(field, str):
        try:
            proton_freq_MHz = float(field)
        except ValueError:
            raise ValueError(
                f'field={field!r} is a string but not a number – pass e.g. '
                f'field="500" for a conversational "500 MHz" magnet, or a '
                f'plain number (field=11.7) for the field strength in Tesla.'
            )
        gamma_1H = find_gamma("1H")
        if gamma_1H is None:
            raise ValueError("Could not look up 1H in the gyromagnetic-ratio table.")
        gamma_1H_MHz_per_T = gamma_1H["gamma"] / 1.0e6
        B0_tesla = proton_freq_MHz / gamma_1H_MHz_per_T
    else:
        B0_tesla = float(field)

    BF1, SFO1, canonical_nuclide = compute_BF1_SFO1(nuclide, B0_tesla)
    return SFO1, B0_tesla, canonical_nuclide


def _hz_to_ppm(x_Hz, nuclide, field, SFO1):
    """
    Resolve an SFO1 (MHz) from an explicit SFO1, or from (nuclide,
    field) via _resolve_SFO1_from_field -- see the module docstring
    for the two ways `field` can be given. Returns (x_ppm or None,
    SFO1 or None): None if no ppm axis could be resolved (caller
    decides whether that's fatal).
    """
    if SFO1 is not None:
        return x_Hz / SFO1, SFO1

    if nuclide is None:
        return None, None

    if field is None:
        raise ValueError(
            f"Converting {nuclide!r} to ppm needs a field (a Tesla float, "
            f'or a conversational 1H-frequency string like "500") or an '
            f"explicit SFO1 – neither was given."
        )

    resolved_SFO1, _, _ = _resolve_SFO1_from_field(nuclide, field)
    return x_Hz / resolved_SFO1, resolved_SFO1


def _normalise(y):
    y = np.asarray(y, dtype=float)
    span = y.max() - y.min()
    if span == 0:
        return y
    return (y - y.min()) / span


# ============================================================
# SIMPSONimport
# ============================================================

def SIMPSONimport(path, nuclide=None, field=None, SFO1=None, mass=1,
                   f1p=0, f2p=0, line_broadening=0.0, zero_fill=None):
    """
    Import a SIMPSON-generated spectrum: .spe, .dat, or a .csdf file
    that is (despite the extension) actually SIMPSON's SIMP text
    format. Format is detected from file content, not extension.
    For genuine CSDM/JSON files (e.g. mrsimulator output), use
    CSDMimport instead.

    Parameters
    ----------
    path : str
        Path to the .spe / .dat / SIMP-text .csdf file.
    nuclide : str, optional
        e.g. "31P". If given with `field` or `SFO1`, an x_ppm axis is
        computed (x_ppm = x_Hz / SFO1[MHz], same convention as
        NMR1dimport). If omitted, x_ppm is None and only x_Hz is set.
    field : str or float, optional
        Required alongside `nuclide` if `SFO1` isn't given directly.
        Two conventions, distinguished by type -- see the module
        docstring:

        - a string, e.g. "500" or "800" -- the conversational field
          name, i.e. the frequency (MHz) 1H resonates at on that
          magnet.
        - a plain number, e.g. 11.7 or 18.8 -- the field strength
          itself, in Tesla.

        field=500 (no quotes) means 500 Tesla, not a "500 MHz" magnet
        -- use field="500" for that.
    SFO1 : float, optional
        Explicit observe frequency in MHz. Takes precedence over
        nuclide/field if given -- unambiguous, so prefer this over
        `field` if you already know SFO1.
    mass : float, optional
        Scales real/imag spectra, mirroring NMR1dimport's convention
        (default 1 -- SIMPSON output isn't mass-normalised the way an
        experimental NS/mass-scaled spectrum is; this is mainly so the
        dict is drop-in compatible).
    f1p, f2p : float, optional
        ppm window to crop to (same convention as NMR1dimport).
        Requires a resolvable ppm axis.
    line_broadening, zero_fill : optional
        Only used if the file's TYPE is FID rather than SPE -- see
        fft_simpson_fid.

    Returns
    -------
    dict with the same keys as NMR1dimport's output (x_ppm, x_Hz,
    real_spectrum, normalised_real_spectrum, imag_spectrum,
    normalised_imag_spectrum, nuclide, BF1, SFO1, path), plus 'NP'
    and 'SW' for reference -- so it can be passed straight into
    SIMPSONplot_1d_stack alongside NMR1dimport results.
    """
    fmt = _sniff_format(path)

    if fmt == 'shape':
        raise ValueError(
            f"{path} looks like a SIMPSON pulse-shape file (2 columns, "
            f"no header), not a spectrum. Use SIMPSONread_shape() instead."
        )

    raw = _read_simp_text(path) if fmt == 'simp' else _read_dat_text(path)
    NP = raw['NP']

    if raw.get('TYPE') == 'FID':
        x_Hz, real, imag = fft_simpson_fid(
            raw['real'], raw['imag'], raw['SW'],
            line_broadening=line_broadening, zero_fill=zero_fill,
        )
    elif 'x_Hz' in raw:
        x_Hz, real, imag = raw['x_Hz'], raw['real'], raw['imag']
    else:
        x_Hz = np.linspace(-raw['SW'] / 2, raw['SW'] / 2, NP, endpoint=False)
        real, imag = raw['real'], raw['imag']

    x_ppm, resolved_SFO1 = (None, None)
    if nuclide is not None or SFO1 is not None:
        x_ppm, resolved_SFO1 = _hz_to_ppm(x_Hz, nuclide, field, SFO1)

    if f1p != 0 or f2p != 0:
        if x_ppm is None:
            raise ValueError(
                "f1p/f2p cropping needs a ppm axis – supply nuclide "
                "(+field or SFO1)."
            )
        # NMR1dimport's crop (np.argmax(xAxppm < f1p)) relies on its
        # ppm axis always being descending (true for Bruker data, per
        # its own SR/O1 convention) -- argmax returns the *first*
        # match, which is only the crossover point if the array starts
        # False. SIMPSONimport's x_Hz/x_ppm is ascending (built via
        # linspace(-SW/2, SW/2, ...)), where that trick silently
        # returns index 0 instead of the crossover -- caught this by
        # testing against ad_echo.spe. Using an explicit mask instead
        # so cropping is correct regardless of axis order.
        lo, hi = (f1p, f2p) if f1p < f2p else (f2p, f1p)
        mask = (x_ppm >= lo) & (x_ppm <= hi)
        if not mask.any():
            raise ValueError(f"No points found between {f1p} and {f2p} ppm.")
        x_ppm, x_Hz = x_ppm[mask], x_Hz[mask]
        real, imag = real[mask], imag[mask]

    real = np.asarray(real) / mass
    imag = np.asarray(imag) / mass

    return {
        'x_ppm': x_ppm, 'x_Hz': x_Hz,
        'real_spectrum': real, 'normalised_real_spectrum': _normalise(real),
        'imag_spectrum': imag, 'normalised_imag_spectrum': _normalise(imag),
        'nuclide': nuclide, 'BF1': None, 'SFO1': resolved_SFO1,
        'path': path, 'NP': NP, 'SW': raw.get('SW'),
    }


# ============================================================
# CSDMimport (genuine CSDM/JSON, e.g. mrsimulator output)
# ============================================================

def CSDMimport(path, nuclide=None, field=None, SFO1=None, mass=1,
               dependent_variable_index=0, component_index=0):
    """
    Import a genuine CSDM/JSON file (e.g. from mrsimulator) via
    csdmpy, returning the same schema as SIMPSONimport/NMR1dimport.

    Verified against csdmpy directly (round-tripped a synthetic 1D
    CSDM file): `cp.load(path)` returns a CSDM object whose first
    dimension exposes `.coordinates.value` (ndarray) and
    `.coordinates.unit` (an astropy Unit -- compare via str()), and
    whose `dependent_variables[i].components[j]` is the (possibly
    complex) data array. Only 1D, single-dependent-variable files are
    handled; extend dependent_variable_index/component_index handling
    if you need more.

    Parameters
    ----------
    path : str
    nuclide, field, SFO1 : optional
        Only used if the file's axis is in Hz rather than already in
        ppm -- see _hz_to_ppm / _resolve_SFO1_from_field, and the
        `field` convention described in the module docstring
        (SIMPSONimport's docstring spells it out in full).
    mass : float, optional
    dependent_variable_index, component_index : int, optional
        Which dependent variable / component to read.

    Returns
    -------
    dict, same schema as SIMPSONimport.
    """
    if not _HAS_CSDMPY:
        raise ImportError(
            "CSDMimport needs the 'csdmpy' package (pip install csdmpy) "
            "to read genuine CSDM/JSON files – a different format from "
            "SIMPSON's SIMP text output. If your file starts with 'SIMP' "
            "rather than '{', it's SIMP text despite the .csdf extension "
            "– use SIMPSONimport for that instead."
        )

    data = cp.load(path)
    dim = data.dimensions[0]
    dv = data.dependent_variables[dependent_variable_index]

    x = np.asarray(dim.coordinates.value)
    unit = str(dim.coordinates.unit)
    y = np.asarray(dv.components[component_index])

    real = np.real(y)
    imag = np.imag(y) if np.iscomplexobj(y) else np.zeros_like(real)

    if unit == 'ppm':
        x_ppm, x_Hz, resolved_SFO1 = x, None, SFO1
    elif unit == 'Hz':
        x_Hz = x
        x_ppm, resolved_SFO1 = _hz_to_ppm(x_Hz, nuclide, field, SFO1)
    else:
        raise ValueError(
            f"{path}: dimension unit is '{unit}' – CSDMimport currently "
            f"only handles 'Hz' and 'ppm' axes, extend it for this case."
        )

    real = real / mass
    imag = imag / mass

    return {
        'x_ppm': x_ppm, 'x_Hz': x_Hz,
        'real_spectrum': real, 'normalised_real_spectrum': _normalise(real),
        'imag_spectrum': imag, 'normalised_imag_spectrum': _normalise(imag),
        'nuclide': nuclide, 'BF1': None, 'SFO1': resolved_SFO1,
        'path': path,
    }


# ============================================================
# Single-point FID series (e.g. pulse-sequence efficiency tests)
# ============================================================

def SIMPSONread_single_point_fid(path):
    """
    Read just the first data point of a SIMPSON FID file -- for
    single-point acquisitions used to evaluate pulse-sequence
    efficiency (e.g. NP=1 nutation/power/offset tests), where the
    quantity of interest is a single complex intensity rather than a
    lineshape. Works for any NP (only the first point is used), so a
    file with more points than strictly needed is handled fine too.

    Parameters
    ----------
    path : str

    Returns
    -------
    dict : 'real', 'imag', 'magnitude' (floats), 'path'.
    """
    fmt = _sniff_format(path)
    if fmt == 'shape':
        raise ValueError(
            f"{path} looks like a SIMPSON pulse-shape file (2 columns, "
            f"no header), not a FID."
        )

    raw = _read_simp_text(path) if fmt == 'simp' else _read_dat_text(path)
    real0, imag0 = float(raw['real'][0]), float(raw['imag'][0])

    return {'real': real0, 'imag': imag0,
            'magnitude': float(np.hypot(real0, imag0)), 'path': path}


def SIMPSONread_fid_series(paths, x=None, xlabel=None):
    """
    Read the first point of each FID file in `paths` -- e.g. a series
    of single-point pulse-sequence-efficiency acquisitions collected
    across a swept parameter (pulse length, RF power, offset, ...) --
    and collect them into arrays ready for SIMPSONplot_fid_series.

    Parameters
    ----------
    paths : list of str
        FID file paths, in the order corresponding to `x`.
    x : array-like, optional
        The swept quantity, one value per path (e.g. pulse durations
        in \u00b5s, or RF amplitudes in kHz). If omitted, x is
        1..len(paths).
    xlabel : str, optional
        Axis label carried through to SIMPSONplot_fid_series (e.g.
        'Pulse length (\u00b5s)').

    Returns
    -------
    dict : 'x', 'real', 'imag', 'magnitude' (ndarrays, one entry per
    path, in `paths` order), 'xlabel', 'paths'.
    """
    if x is not None and len(x) != len(paths):
        raise ValueError(
            f"x has {len(x)} values but {len(paths)} paths were given – "
            f"they must correspond 1:1."
        )

    real = np.empty(len(paths))
    imag = np.empty(len(paths))
    magnitude = np.empty(len(paths))
    for i, p in enumerate(paths):
        point = SIMPSONread_single_point_fid(p)
        real[i], imag[i], magnitude[i] = point['real'], point['imag'], point['magnitude']

    x_arr = np.asarray(x, dtype=float) if x is not None else np.arange(1, len(paths) + 1, dtype=float)

    return {'x': x_arr, 'real': real, 'imag': imag, 'magnitude': magnitude,
            'xlabel': xlabel, 'paths': list(paths)}


# ============================================================
# Plotting: stacked spectra from pre-imported result dicts
# ============================================================

def SIMPSONplot_1d_stack(spectra, labels=None, linestyles=None, colours=None,
                   xlims='default', xlabel=None, pl_width=3.375, pl_height=3.375,
                   normalise=True, yoffset=0.2, font='Arial', fontsize=12,
                   x_unit='ppm', output_format='',
                   tick_dir='in', tick_length=4.0, tick_width=1.0, tick_pad=4.0,
                   tick_number=None, field='', legend=False,
                   save_fig=False, fig_name='nmr_1d_stack', save_format='png'):
    """
    Stacked plot of a list of already-imported 1D spectrum dicts --
    from NMR1dimport, SIMPSONimport, CSDMimport, or anything else
    producing the same schema (x_ppm/x_Hz, real_spectrum,
    normalised_real_spectrum, nuclide, SFO1). This is the mixed-source
    counterpart to one_d.NMR1dplot, which only accepts Bruker
    directory paths -- see this module's docstring for why the two
    aren't unified.

    Parameters
    ----------
    spectra : list of dict
        Result dicts to plot, in stacking order.
    labels : list of str, optional
        Legend label for each spectrum (e.g. "experimental",
        "SIMPSON sim"). If omitted, no per-spectrum legend labels are
        set (but see `legend`).
    linestyles : list of str, optional
        Matplotlib linestyle per spectrum (e.g. dash simulated spectra
        vs solid experimental ones). Defaults to solid for all.
    colours : list, optional
        Explicit colour per spectrum. If omitted, falls back to
        get_stack_colormap('black') stepped across the stack (same
        default as NMR1dplot).
    xlims, xlabel, pl_width, pl_height, normalise, yoffset, font,
    fontsize, x_unit, output_format, tick_dir, tick_length,
    tick_width, tick_pad, tick_number, field, save_fig, fig_name,
    save_format : optional
        Mirror the corresponding NMR1dplot parameters.
    legend : bool, optional
        Force-draw a legend even if no per-spectrum `labels` were
        given (matplotlib will just omit unlabelled lines).

    Returns
    -------
    fig, ax
    """
    if not spectra:
        raise ValueError("spectra must contain at least one result dict.")

    style = setup_plotting(font=font, fontsize=fontsize, pl_width=pl_width,
                            pl_height=pl_height, output_format=output_format)
    pl_width, pl_height = style['pl_width'], style['pl_height']

    n = len(spectra)

    if colours is None:
        cmap = get_stack_colormap('black')
        norm = plt.Normalize(vmin=0, vmax=max(n - 1, 1))
        scalarMap = cmx.ScalarMappable(norm=norm, cmap=cmap)
        colours = [scalarMap.to_rgba(i) for i in range(n)]

    if linestyles is None:
        linestyles = ['solid'] * n

    if labels is None:
        labels = [None] * n

    fig, ax = plt.subplots()

    yBase = 0
    xmin = xmax = labeltext = None

    for i, results in enumerate(spectra):
        x = results.get('x_ppm') if x_unit == 'ppm' else results.get('x_Hz')
        if x is None:
            raise ValueError(
                f"Spectrum {i} ({results.get('path')}) has no x_{x_unit} "
                f"axis – for SIMPSON/CSDM imports this means "
                f"nuclide/field/SFO1 wasn't supplied at import time."
            )
        y = results['normalised_real_spectrum'] if normalise else results['real_spectrum']

        this_xmin, this_xmax = x[0], x[-1]
        if this_xmin > this_xmax:
            this_xmin, this_xmax = this_xmax, this_xmin
        xmin = this_xmin if xmin is None else min(xmin, this_xmin)
        xmax = this_xmax if xmax is None else max(xmax, this_xmax)

        if results.get('nuclide'):
            nucgamma = find_gamma(results['nuclide'], field=field, SFO1=results.get('SFO1'))
            labeltext = NUC_label(nucgamma['Nuclide'], x_unit=x_unit)

        ax.plot(x, y + yBase, color=colours[i], linestyle=linestyles[i],
                linewidth=1.5, label=labels[i])

        yBase += max(y) * (1 + yoffset)

    if xlims == 'default':
        ax.set_xlim(xmin, xmax)
    else:
        ax.set_xlim(xlims[0], xlims[1])

    ax.set_xlabel(_italic_label(xlabel if xlabel is not None else labeltext))
    apply_spine_style(ax, top=False, right=False, bottom=True, left=False)
    ax.set_yticks([])
    apply_tick_style(ax, direction=tick_dir, length=tick_length, width=tick_width,
                      pad=tick_pad, num_ticks=tick_number, axis='x')
    ax.invert_xaxis()

    if legend or any(labels):
        ax.legend(frameon=False)

    fig.set_figheight(pl_height)
    fig.set_figwidth(pl_width)
    fig.tight_layout()

    if save_fig:
        save_figure(fig, fig_name=fig_name, save_format=save_format)

    return fig, ax


# ============================================================
# Plotting: pulse shape
# ============================================================

def SIMPSONplot_shape(path, duration_us=None, pl_width=3.375, pl_height=2.5,
               font='Arial', fontsize=12, save_fig=False,
               fig_name='pulse_shape', save_format='png', fig=None, show_offset=False):
    """
    Plot amplitude and phase of a SIMPSON pulse-shape file as two
    stacked panels. Deliberately separate from SIMPSONplot_1d_stack: a pulse
    shape isn't a spectrum (x-axis is point index/time, not
    frequency; data is amplitude/phase, not real/imaginary intensity)
    and overlaying it with spectra would misrepresent it.

    Parameters
    ----------
    path : str
    duration_us : float, optional
        Total pulse duration in microseconds. If given -- or written in the
        file name, e.g. ``..._10.0us_...`` -- the x-axis is time (us), each
        element drawn as the step it is (``duration / N`` long, SIMPSON's
        convention); otherwise it is the point number.
    fig : matplotlib Figure, optional
        Draw into this figure (the GUI does) instead of making one.
    show_offset : bool
        Add a third panel: the frequency sweep the phase encodes
        (``(1/360) dphi/dt``, see :func:`SIMPSONshape_profile`). Needs a
        pulse length.

    The amplitude is shown as nu1 in kHz and the phase unwrapped (a phase
    written modulo 360 degrees is the continuous sweep it encodes).

    Returns
    -------
    fig, (ax_amplitude, ax_phase) -- or (ax_amplitude, ax_phase, ax_offset)
    with ``show_offset`` and a pulse length.
    """
    profile = SIMPSONshape_profile(path, duration_us)
    n = profile['npoints']
    timed = profile['duration_us'] is not None
    # Each element is a step: drawn from its start to the next one's.
    x = (np.append(profile['t_us'], profile['duration_us']) if timed
         else np.arange(n + 1, dtype=float))
    xlabel = r'$\mathit{t}$' + ' (µs)' if timed else 'Point'
    amplitude = np.append(profile['amplitude_Hz'], profile['amplitude_Hz'][-1]) / 1e3
    phase = np.append(profile['phase_unwrapped_deg'], profile['phase_unwrapped_deg'][-1])
    with_offset = bool(show_offset and timed and profile['offset_Hz'] is not None)
    rows = 3 if with_offset else 2

    if fig is None:
        style = setup_plotting(font=font, fontsize=fontsize, pl_width=pl_width,
                                pl_height=pl_height)
        pl_width, pl_height = style['pl_width'], style['pl_height']
        fig, axes = plt.subplots(rows, 1, sharex=True)
        fig.set_figheight(pl_height * (1.4 if rows == 3 else 1.0))
        fig.set_figwidth(pl_width)
    else:
        fig.clear()
        axes = fig.subplots(rows, 1, sharex=True)
    ax1, ax2 = axes[0], axes[1]
    ax1.plot(x, amplitude, color='black', linewidth=1.2, drawstyle='steps-post')
    ax1.set_ylabel(r'$\mathit{\nu}_1$ (kHz)')
    apply_spine_style(ax1, top=False, right=False)

    ax2.plot(x, phase, color='black', linewidth=1.2, drawstyle='steps-post')
    ax2.set_ylabel(r'$\mathit{\phi}$' + ' (°)')
    apply_spine_style(ax2, top=False, right=False)
    if with_offset:
        ax3 = axes[2]
        ax3.plot(profile['t_offset_us'], profile['offset_Hz'] / 1e3, color='black',
                 linewidth=1.2)
        ax3.set_ylabel(r'$\Delta\mathit{\nu}$ (kHz)')
        apply_spine_style(ax3, top=False, right=False)
    axes[-1].set_xlabel(xlabel)
    axes[0].set_xlim(x[0], x[-1])

    if not getattr(fig, '_opennmr_managed', False):
        fig.tight_layout()

    if save_fig:
        save_figure(fig, fig_name=fig_name, save_format=save_format)

    return fig, tuple(axes)


# ============================================================
# Plotting: FID and its apodization window
# ============================================================

def SIMPSONplot_fid(fid, apodization=None, apod_params=None, show_imag=True,
             show_window=True, overlay_apodized=True,
             pl_width=3.375, pl_height=2.5, font='Arial', fontsize=12,
             tick_dir='in', tick_length=4.0, tick_width=1.0, tick_pad=4.0,
             save_fig=False, fig_name='fid_plot', save_format='png'):
    """
    Plot a raw FID (as read by SIMPSONread_fid) against time, optionally with
    an apodization window (see SIMPSONapodization_window) and the resulting
    apodized FID overlaid -- so the effect of a chosen window can be
    checked before it's baked into fft_simpson_fid.

    Parameters
    ----------
    fid : dict
        Output of SIMPSONread_fid.
    apodization : str, optional
        Window kind (see SIMPSONapodization_window). If omitted/None, only
        the raw FID is plotted.
    apod_params : dict, optional
        Extra kwargs for SIMPSONapodization_window (lb, gb, sine_offset,
        sine_end).
    show_imag : bool, optional
        Also plot the imaginary channel of the raw FID. Default True.
    show_window : bool, optional
        Overlay the window function itself, scaled to the FID's peak
        amplitude so its shape is visible against the decay. Default
        True (only has an effect if `apodization` is given).
    overlay_apodized : bool, optional
        Also overlay the apodized real FID. Default True (only has an
        effect if `apodization` is given).
    pl_width, pl_height, font, fontsize, tick_dir, tick_length,
    tick_width, tick_pad, save_fig, fig_name, save_format : optional
        Mirror the plotting conventions used elsewhere in this module.

    Returns
    -------
    fig, ax
    """
    style = setup_plotting(font=font, fontsize=fontsize, pl_width=pl_width,
                            pl_height=pl_height)
    pl_width, pl_height = style['pl_width'], style['pl_height']

    fig, ax = plt.subplots()
    t_us = fid['t'] * 1e6

    ax.plot(t_us, fid['real'], color='black', linewidth=1.0, label='real')
    if show_imag:
        ax.plot(t_us, fid['imag'], color='grey', linewidth=1.0,
                linestyle='--', label='imag')

    if apodization and apodization != 'none':
        apod_params = apod_params or {}
        _, window = SIMPSONapodization_window(fid['NP'], fid['dt'], kind=apodization, **apod_params)

        if show_window:
            peak = np.max(np.abs(fid['real']))
            scale = peak if peak > 0 else 1.0
            ax.plot(t_us, window * scale, color='C1', linewidth=1.2,
                    linestyle=':', label=f'{apodization} window')

        if overlay_apodized:
            _, real_a, _, _ = apply_apodization(fid['real'], fid['imag'], fid['SW'],
                                                 kind=apodization, **apod_params)
            ax.plot(t_us, real_a, color='C0', linewidth=1.0,
                    label='apodized (real)')

    ax.set_xlabel(_italic_label('Time (\u00b5s)'))
    ax.set_ylabel(_italic_label('Intensity'))
    apply_spine_style(ax, top=False, right=False)
    apply_tick_style(ax, direction=tick_dir, length=tick_length, width=tick_width,
                      pad=tick_pad)
    ax.legend(frameon=False, fontsize=fontsize * 0.7)

    fig.set_figheight(pl_height)
    fig.set_figwidth(pl_width)
    fig.tight_layout()

    if save_fig:
        save_figure(fig, fig_name=fig_name, save_format=save_format)

    return fig, ax


# ============================================================
# Plotting: single-point FID series (e.g. pulse-sequence efficiency)
# ============================================================

def SIMPSONplot_fid_series(series, y='magnitude', xlabel=None, ylabel=None,
                     normalise=False, marker='o', linestyle='-', color='black',
                     pl_width=3.375, pl_height=2.5, font='Arial', fontsize=12,
                     tick_dir='in', tick_length=4.0, tick_width=1.0, tick_pad=4.0,
                     save_fig=False, fig_name='fid_series', save_format='png'):
    """
    Plot the first-point intensity from a series of single-point FIDs
    (see SIMPSONread_fid_series) against the swept quantity -- e.g. a
    nutation curve, an RF power-efficiency curve, an offset profile.

    Parameters
    ----------
    series : dict
        Output of SIMPSONread_fid_series.
    y : {'magnitude', 'real', 'imag'}, optional
        Which component of the first point to plot. Default
        'magnitude' (sign-insensitive, usually what you want for a
        pure efficiency check; use 'real' if phase/sign matters, e.g.
        a nutation curve that should go negative).
    xlabel, ylabel : str, optional
        Override axis labels. `xlabel` falls back to
        series['xlabel'], then plain 'x'; `ylabel` falls back to
        y.capitalize().
    normalise : bool, optional
        Scale y to [0, 1]. Default False.
    marker, linestyle, color : optional
        Mirror matplotlib's own plot() kwargs.
    pl_width, pl_height, font, fontsize, tick_dir, tick_length,
    tick_width, tick_pad, save_fig, fig_name, save_format : optional
        Mirror the plotting conventions used elsewhere in this module.

    Returns
    -------
    fig, ax
    """
    if y not in ('magnitude', 'real', 'imag'):
        raise ValueError("y must be 'magnitude', 'real', or 'imag'.")

    yvals = series[y]
    if normalise:
        yvals = _normalise(yvals)

    style = setup_plotting(font=font, fontsize=fontsize, pl_width=pl_width,
                            pl_height=pl_height)
    pl_width, pl_height = style['pl_width'], style['pl_height']

    fig, ax = plt.subplots()
    ax.plot(series['x'], yvals, color=color, marker=marker, linestyle=linestyle,
            linewidth=1.2)

    ax.set_xlabel(_italic_label(xlabel if xlabel is not None else (series.get('xlabel') or 'x')))
    ax.set_ylabel(_italic_label(ylabel if ylabel is not None else y.capitalize()))
    apply_spine_style(ax, top=False, right=False)
    apply_tick_style(ax, direction=tick_dir, length=tick_length, width=tick_width,
                      pad=tick_pad)

    fig.set_figheight(pl_height)
    fig.set_figwidth(pl_width)
    fig.tight_layout()

    if save_fig:
        save_figure(fig, fig_name=fig_name, save_format=save_format)

    return fig, ax


def _italic_label(text):
    """Quantity symbols italic (plotting.labels.italicise_symbols)."""
    from opennmr.plotting.labels import italicise_symbols
    return italicise_symbols(text)


# ============================================================
# Loading a SIMPSON file as an openNMR spectrum (shared with the GUI)
# ============================================================

def SIMPSONload(path, nuclide=None, field=None, SFO1=None, reference_ppm=0.0, kind=None,
                element=0, **processing):
    """
    Read a SIMPSON spectrum (.spe) or FID (.fid) as an
    :class:`~opennmr.core.spectrum.NMRSpectrum` -- the object the GUI's Open
    experiments holds, so everything that works on a measured spectrum works on
    it (``SIMPSONfit_spectrum``, ``export_spectrum``, plotting, referencing...).

    A FID is processed here with the usual controls: ``window`` ("exponential",
    "gaussian", "sine", ...), ``window_kwargs={"lb": 20}``, ``zero_fill``,
    ``truncate``, ``autophase``/``phase0``/``phase1``; and the GUI offers the same
    ones live once it is in Open experiments. See :mod:`opennmr.io.simpson` for
    the conventions (FIDs are conjugated on reading so lines fall where
    SIMPSON's own ``fft`` puts them).

    Parameters
    ----------
    nuclide, field, SFO1 : optional
        As in :func:`SIMPSONimport`: with them the axis is ppm, without they
        are Hz. ``field="500"`` is a "500 MHz" magnet; ``field=11.7`` is Tesla.
    reference_ppm : float
        The shift the carrier (0 Hz) stands for, added to the ppm axis.
    kind : {"fid", "spe"}, optional
        For a headerless ``fsave -xreim`` .dat file (x, real, imaginary
        columns): left out, a file whose x column runs through zero is read
        as a spectrum (Hz about the carrier) and one that starts at or after
        zero as a FID (give ``sw=`` or a time unit with ``time_unit=``).
    element : int
        Which of the FIDs/spectra of a file with ``NELEM`` > 1 (0-based); see
        :func:`opennmr.io.simpson.n_elements`.

    A FID or spectrum may have real and imaginary parts (``re im`` per line in
    SIMP text, three columns in a .dat); both are kept. A pulse shape, scan
    table or input script is not read here: use :func:`SIMPSONread_shape`,
    :func:`SIMPSONread_table` and :func:`SIMPSONread_script`.
    """
    from ..io import simpson as _simpson_io
    return _simpson_io.read_1d(path, nucleus=nuclide, field=field, sfo1=SFO1,
                               reference_ppm=reference_ppm, kind=kind, element=element, **processing)


# ============================================================
# Parameter-scan tables and input scripts
# ============================================================

def SIMPSONread_table(path):
    """
    Read a headerless three-column SIMPSON scan table (x, y, z) -- e.g. the
    efficiency of a pulse over a grid of rf amplitudes and offsets.

    A file whose first column is one evenly spaced axis is x, real, imaginary
    (a spectrum or FID): read that with :func:`SIMPSONload`.

    Returns
    -------
    dict : ``x``, ``y``, ``z`` (the columns); and, when x and y form a complete
    grid, ``grid=True`` with ``xs``, ``ys`` and ``Z`` (``Z[j, i]`` at
    ``ys[j]``, ``xs[i]``).
    """
    from ..io import simpson as _simpson_io
    return _simpson_io.read_table(path)


def SIMPSONread_script(path):
    """
    Read the nucleus and field out of a SIMPSON input script (.tcl), to fill
    in ``nuclide=`` and ``field=`` for :func:`SIMPSONload`. The script is
    never run; only numbers and arithmetic on them are evaluated.

    Returns
    -------
    dict : ``nucleus``, ``channels``, ``proton_mhz`` (the ``proton_frequency``
    in MHz -- pass ``field=str(proton_mhz)``), ``spin_rate``, ``sw``, ``np``;
    ``None`` where the script does not give a plain number.
    """
    from ..io import simpson as _simpson_io
    return _simpson_io.read_tcl_settings(path)


def SIMPSONplot_table(table, mode='auto', xlabel='x', ylabel='y', zlabel='z',
                      cmap='viridis', ax=None, pl_width=3.375, pl_height=2.5,
                      font='Arial', fontsize=12, save_fig=False,
                      fig_name='simpson_table', save_format='png'):
    """
    Plot a scan table from :func:`SIMPSONread_table` (or its path).

    mode : {"auto", "map", "lines"}
        ``"map"``: z as colour over the x-y grid (the default when the table is
        a complete grid); ``"lines"``: z against x, one line per y (or a
        single line when the table is not a grid).
    xlabel, ylabel, zlabel : str
        Axis and colour-bar text (quantity symbols are italicised).

    Returns ``(fig, ax)``.
    """
    from ..plotting.accessibility import default_series_colours
    from ..plotting.labels import italicise_symbols
    if isinstance(table, str):
        table = SIMPSONread_table(table)
    if mode not in ('auto', 'map', 'lines'):
        raise ValueError("mode must be 'auto', 'map' or 'lines'.")
    if mode == 'auto':
        mode = 'map' if table.get('grid') else 'lines'
    if mode == 'map' and not table.get('grid'):
        raise ValueError('mode="map" needs x and y to form a complete grid.')
    if ax is None:
        style = setup_plotting(font=font, fontsize=fontsize, pl_width=pl_width,
                               pl_height=pl_height)
        fig, ax = plt.subplots()
        fig.set_figwidth(style['pl_width'])
        fig.set_figheight(style['pl_height'])
    else:
        fig = ax.figure
    if mode == 'map':
        xs, ys, grid = table['xs'], table['ys'], table['Z']
        mesh = ax.pcolormesh(xs, ys, grid, cmap=cmap, shading='nearest')
        colour_bar = fig.colorbar(mesh, ax=ax)
        colour_bar.set_label(italicise_symbols(zlabel))
        ax.set_ylabel(italicise_symbols(ylabel))
    else:
        if table.get('grid'):
            ys = table['ys']
            colours = default_series_colours(len(ys))
            for j, y_value in enumerate(ys):
                ax.plot(table['xs'], table['Z'][j], color=colours[j % len(colours)],
                        linewidth=1.2, label=f'{y_value:g}')
            if len(ys) <= 8:
                ax.legend(frameon=False, title=italicise_symbols(ylabel))
        else:
            ax.plot(table['x'], table['z'], color='black', linewidth=1.2)
        ax.set_ylabel(italicise_symbols(zlabel))
    ax.set_xlabel(italicise_symbols(xlabel))
    for side in ('top', 'right'):
        if mode == 'lines':
            ax.spines[side].set_visible(False)
    if not getattr(fig, '_opennmr_managed', False):
        try:
            fig.tight_layout()
        except Exception:  # noqa: BLE001 -- layout is cosmetic
            pass
    if save_fig:
        save_figure(fig, fig_name=fig_name, save_format=save_format)
    return fig, ax
